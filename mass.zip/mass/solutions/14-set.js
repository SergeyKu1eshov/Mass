//BEGIN
export const countUniqChars = (mess) => {
    return new Set(mess).size;
}
export default countUniqChars;
//END