//BEGIN
export const get = (mass, ind, val = null) => {
    return 0 <= ind && ind < mass.length ? mass[index] : val;
}
export default get;
//END